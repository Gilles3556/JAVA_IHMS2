package ent.etrs.pndg.start;

import ent.etrs.pndg.ihm.*;
import ent.etrs.pndg.ihm.menus.FabriqueMenu;
import ent.etrs.pndg.ihm.menus.MenuInt;
import ent.etrs.pndg.ihm.menus.Saisissable;

public class LanceurMenu {
    public static void main(String[] args) {
        try {
            //code pour un menu console char
            Ihm vueTechnique = FabriqueIhm.creerIhm(TypeIhm.CONSOLE);

            Saisissable menu1 = FabriqueMenu.creerMenuChar("--Menu TypeAlignement", TypeAlignement.values(),true);
            int chx = menu1.saisirChoixEntierMenu(vueTechnique);
            vueTechnique.afficherChaine("Votre choix: "+chx);

            //code pour un menu jpanel int
            Ihm vueTechnique1 = FabriqueIhm.creerIhm(TypeIhm.JPANEL);

            Saisissable menu2 = FabriqueMenu.creerMenuInt("--Menu TA",TypeAlignement.values(),false);
            int chx2 =menu2.saisirChoixEntierMenu(vueTechnique1);
            vueTechnique1.afficherChaine("votre choix int="+chx2+" , char="+((char)chx2));

        }catch(Exception ex){
            ex.printStackTrace();
        }


    }
}
