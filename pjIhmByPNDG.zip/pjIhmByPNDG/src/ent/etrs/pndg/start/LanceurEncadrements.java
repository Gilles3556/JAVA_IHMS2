package ent.etrs.pndg.start;

import ent.etrs.pndg.ihm.*;
import ent.etrs.pndg.ihm.menus.FabriqueMenu;
import ent.etrs.pndg.ihm.menus.Saisissable;

public class LanceurEncadrements {
    public static void main(String[] args) {

        //encadrement d'une chaine simple
        String n= "Penaud";
        System.out.println("\n>>chaine: true, true,true");
        System.out.println(OutilsIhm.encadrerStr(n,true,true,true));

        System.out.println("\n>>chaine: false, true,false");
        System.out.println(OutilsIhm.encadrerStr(n,false,true,false));

        System.out.println("\n>>chaine: false, false,true");
        System.out.println(OutilsIhm.encadrerStr(n,false,false,true));

        //encadrement d'un tableau de chaine
        System.out.println("\n>>tableau de chaine: false,false,false");
        String [] tablo ={"Gérard","MENVUSSA","lkgfmfkglmkj"};
        System.out.println(OutilsIhm.encadrerStrTab(tablo));

        //encadrrment d'un menu
        try {
            //code pour un menu console char
            Ihm vueTechnique = FabriqueIhm.creerIhm(TypeIhm.JPANEL);

            Saisissable menu1 = FabriqueMenu.creerMenuChar("--Menu TypeAlignement", TypeAlignement.values(),false);

            int chx = menu1.saisirChoixEntierMenu(vueTechnique);
            System.out.println("chx="+chx);


        }catch(Exception ex){
            ex.printStackTrace();
        }


    }
}
