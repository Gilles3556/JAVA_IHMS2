package ent.etrs.pndg.start;

import ent.etrs.pndg.ihm.FabriqueIhm;
import ent.etrs.pndg.ihm.Ihm;
import ent.etrs.pndg.ihm.TypeAlignement;
import ent.etrs.pndg.ihm.TypeIhm;
import ent.etrs.pndg.ihm.exceptions.IhmException;


public class LanceurPndg {
    public static void main(String[] args) {
        String titreTableau="Les élèves";

        String[] tabEntetes={"Nom","Prénom","age","NIA"};

        String[][] tabDonnees= {
                {"MENVUSSA", "Gérard", "45","1234567"},
                {"TERIEUR", "Alexandre"},
                {"TERIEUR", "Alain", "26","F252525"},
                {"OCHON", "Paul", "19"}
        };

        TypeAlignement[] tabTa={TypeAlignement.LEFT,TypeAlignement.CENTER,TypeAlignement.CENTER,TypeAlignement.LEFT};

        //Affichage du contenu du tableau
        Ihm vue = FabriqueIhm.creerIhm(TypeIhm.JPANEL);

        try {
            //Affichage avec colonne NO
            vue.afficherTableau(titreTableau, tabEntetes, tabDonnees, tabTa, true);

            //ou Affichage sans colonne NO
            vue.afficherTableau(titreTableau,tabEntetes,tabDonnees,tabTa,false);
        }catch(Exception ex){
            ex.printStackTrace();
        }

    }

}
