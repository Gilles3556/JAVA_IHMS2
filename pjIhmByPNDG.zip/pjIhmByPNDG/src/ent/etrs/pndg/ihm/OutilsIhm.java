package ent.etrs.pndg.ihm;


import java.util.Arrays;
import java.util.Objects;

public final class OutilsIhm {
    private OutilsIhm(){}
     //---------------------------------------MENUS
    /**
     * Méthode chargée de créer un menu sous la forme d'une chaîne.
     * Ajoute le choix 0] Quitter et l'invite de saisie
     * @param strMenu: String, le titre
     * @param tabloDesOptions: Object[], les options du menu (choix)
     * @return String
     */
    public static String construireMenu(String strMenu,Object[] tabloDesOptions){
        StringBuilder strbMenu = new StringBuilder();

        strbMenu.append(strMenu);
        strbMenu.append(System.lineSeparator());

        for(int i = 0; i< tabloDesOptions.length; i++) {
            strbMenu.append(String.format("%n %d %s",(i+1), tabloDesOptions[i].toString()));
        }
        //MEP du choix QUITTER
        strbMenu.append(String.format("%n  %d] Quitter", 0,ConstantesIhm.CHOIX_QUITTER));
        strbMenu.append(System.lineSeparator());
        //MEP de l'invite de saisie
        strbMenu.append(String.format("%n %s", ConstantesIhm.INVITE));

        return strbMenu.toString();
    }

    /**
     * Méthode chargée transformer un tableau d'options en tableau de chaine.
     * Particulièrement bien adapté pour les Enum !
     * @param tabloOptions: Object[]
     * @return String[]
     */
    public static String[] getStringTabloFrom(Object[] tabloOptions){
        String[] tab= new String[tabloOptions.length];
        for (int i=0;i<tabloOptions.length;i++){
            Object obj = tabloOptions[i];
            tab[i]=obj.toString();
        }
        return tab;
    }


    //--------------formattage de chaine

    /**
     * Méthode permettant de centrer un texte sur une longeur donnée avec un carcatère donné.
     * @param s:String
     * @param size:int, lg de chaîne attendu
     * @param pad: char, caractère de remplissage
     * @return String
     */
    public static String center(String s, int size, char pad) {
        if (s == null || size <= s.length())
            return s;

        StringBuilder sb = new StringBuilder(size+2);

        for (int i = 0; i < (size - s.length()) / 2; i++) {
            sb.append(pad);
        }
        sb.append(s);
        while (sb.length() < size) {
            sb.append(pad);
        }
        return sb.toString();
    }

    /**
     * Méthode permettant d'appliquer un type d'alignement sur une chaîne.
     * @param ta:TypeAlignement
     * @param str:String
     * @param lgm: int
     * @return String
     */
    public static String alignerTexte(TypeAlignement ta, String str, int lgm){
        String strw=null;
        switch(ta){
            case CENTER:
                strw = center(str,lgm,'.');
                strw= "! "+strw+" ";
                break;
            case RIGHT:
                String modele = "! %" + lgm + "s ";
                strw = String.format(modele, str);
                break;
            case LEFT:
                String modele2 = "! %-" + lgm + "s ";

                strw = String.format(modele2, str);
                break;
            case JUSTIFY:
                strw= str;
//                while(strw.length()<lgm){
//                    strw=".";
//                }
                strw+=".".repeat(lgm-1);

                break;
        }

        return strw;
    }

    public static  boolean isCharInTableau(char c, char[] tablo){
        boolean trouve= false;
        int idx=0;
        do{
            if( c == tablo[idx]){
                trouve = true;
            }else {
                idx++;
            }
        }while(!trouve && idx<tablo.length);
        return trouve;
    }
    public static  boolean isIntInTableau(int c, int[] tablo){
        boolean trouve= false;
        int idx=0;
        do{
            if( c == tablo[idx]){
                trouve = true;
            }else {
                idx++;
            }
        }while(!trouve && idx<tablo.length);
        return trouve;
    }

   ////////////////////////////////// Les encadrements ////////////////////////////////////////////
    public final static char CAR_COIN='+';
    public final static char CAR_TIRET='-';
    public final static char CAR_VIDE=' ';
    public final static char CAR_COTE='|';
    public final static char CAR_POINT='.';

    private static String tracerLigne(int nb,char car,boolean coin) {

        StringBuilder sb = new StringBuilder();
        if (coin) {
            sb.append(CAR_COIN);

        }
        for (int c = 0; c < (nb); c++) {
            sb.append(car);
        }
        if (coin){
            sb.append(CAR_COIN);
        }
        return sb.toString();
    }

    public static String ajusterChaine(String str, int lgMax){
        while(str.length()<lgMax){
            str+=" ";
        }
        return str;
    }
    public static String encadrerStr(String str,boolean coin,boolean traitD,boolean traitG){
        StringBuilder sb = new StringBuilder();
        int lg=ajusterLongeurCoinBords(str.length(),coin,traitD,traitG);
        sb.append(tracerLigne(lg,CAR_TIRET,coin)).append(System.lineSeparator());//ligne du haut

        if(traitG)
           sb.append(CAR_COTE).append(" "); //coté G

        sb.append(ajusterChaine(str,lg-2));

        if(traitD)
            sb.append(" ").append(CAR_COTE); //coté D

        sb.append(System.lineSeparator()).append(tracerLigne(lg,CAR_TIRET,coin));

        return sb.toString();
    }

    private static int ajusterLongeurCoinBords(int lg, boolean coin,boolean traitD,boolean traitG){
        //ajustement de la lg si COIN, si traitD, si traitG
        //avec coin
        if(coin){
            lg+=2;
        }
        //avec trait D
        if(traitD){
            lg+=2;
        }
        //avec trait G
        if(traitG){
            lg+=2;
        }
        return lg;
    }

    //Encadrer String[]
    private static int calculerLongueurMax(String[] tab){
        int lgMax=0;

        for(int i=0;i<tab.length;i++){
            if(Objects.nonNull(tab[i])) {
                if (tab[i].length() > lgMax) {
                    lgMax = tab[i].length();
                }
            }
        }
        return lgMax;
    }

    private static int ajusterLongeurCoinBords2(int lgM, int nbStr,boolean coin,boolean traitD,boolean traitG){
        //ajustement de la lg si COIN, si traitD, si traitG
        if(coin){
            lgM+=2;
        }
        if(traitD){
            lgM+=2;
        }
        if(traitG)
            lgM+=2;

        return lgM;
    }

    private static String bordurerChaine( int i,String str,boolean traitD,boolean traitG){
        StringBuilder sb = new StringBuilder();
        //gestion du côté G
        if(traitG){
            sb.append(CAR_COTE).append(" "); //côté G
        }
        //Utilisation STRING

        sb.append(str);

        //gestion du côté D
        if(traitD){
            sb.append(" ").append(CAR_COTE); //coté D
        }
        return sb.toString();
    }
    public static String encadrerStrTab(String[] tab){
        StringBuilder sb = new StringBuilder();

        int lgMax = calculerLongueurMax(tab); //Lg  max des chaines
        int nbChaine = tab.length;
        int lg1=ajusterLongeurCoinBords2(lgMax,nbChaine,true,false,true);

        sb.append(tracerLigne((lg1*nbChaine-(nbChaine*2)),CAR_TIRET,true)).append(System.lineSeparator()); //ligne du haut

        for(int i=0;i<tab.length;i++) {
            if(Objects.nonNull(tab[i])) {
                String strAjustee = ajusterChaine(tab[i], lgMax);
                sb.append(bordurerChaine(i,strAjustee,false,true));

            }
        }
        sb.append(" ").append(CAR_COTE); //coté D

        sb.append(System.lineSeparator());
        sb.append(tracerLigne((lg1*nbChaine-(nbChaine*2)),CAR_TIRET,true)).append(System.lineSeparator()); //ligne du bas
        return sb.toString();
    }
    public static String encadrerStrMenu(String[] tab){
        StringBuilder sb = new StringBuilder();

        int lgMax = calculerLongueurMax(tab); //Lg  max des chaines
        int nbChaine = tab.length;
        //int lg1=ajusterLongeurCoinBords2(lgMax,nbChaine,true,false,true);

        int lg1 = lgMax;
        //sb.append(tracerLigne((lg1*nbChaine-(nbChaine*2)),CAR_TIRET,true)).append(System.lineSeparator()); //ligne du haut
        sb.append(tracerLigne(lg1,CAR_TIRET,true)).append(System.lineSeparator()); //ligne du haut
        int i=0;
        for( i=0;i<tab.length-1;i++) {
            if(Objects.nonNull(tab[i])) {
                String strAjustee = ajusterChaine(tab[i], lgMax-2);
                sb.append(bordurerChaine(i,strAjustee,true,true));
                sb.append(System.lineSeparator());
                if(i==0){ //cas du titre
                    sb.append(tracerLigne(lg1,CAR_TIRET,true)).append(System.lineSeparator()); //ligne du haut
                }
            }
        }
        sb.append(tracerLigne(lg1,CAR_TIRET,true)).append(System.lineSeparator()); //ligne du haut

        sb.append(tab[i]).append(System.lineSeparator());
        return sb.toString();
    }

    //encadre un Menu
    public static String encadrerStrMenu(String strMenu){
        StringBuilder sbMenu = new StringBuilder();
        String[] tab = strMenu.split(System.lineSeparator()) ;

        sbMenu.append(encadrerStrMenu(tab));

        return sbMenu.toString();
    }
}
