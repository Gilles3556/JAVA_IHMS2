package ent.etrs.pndg.ihm;

public enum TypeAlignement {
    RIGHT,LEFT,JUSTIFY,CENTER;
}
