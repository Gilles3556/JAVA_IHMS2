package ent.etrs.pndg.ihm;

public enum TypeIhm {
    CONSOLE,JPANEL;
}
