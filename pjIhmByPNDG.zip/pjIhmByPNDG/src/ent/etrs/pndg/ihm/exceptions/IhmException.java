package ent.etrs.pndg.ihm.exceptions;

public class IhmException extends Exception{
    public IhmException(String msg){
        super(msg);
    }
}
