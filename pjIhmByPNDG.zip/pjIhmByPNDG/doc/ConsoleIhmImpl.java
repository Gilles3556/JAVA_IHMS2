package ent.etrs.pndg.ihm;




import ent.etrs.pndg.ihm.exceptions.IhmException;

import java.util.Objects;
import java.util.Scanner;

public class ConsoleIhmImpl implements Ihm {
    private final Scanner scan = new Scanner(System.in);

    @Override
    public String saisirChaine(String invite) {
        String str = null;
        //0 afficher le message
        afficherChaine(invite, true);
        //1 saisir la chaine demandée
        str = scan.nextLine();

        return str;
    }

    @Override
    public int saisirChoixMenu(String[] tabloStr) throws IhmException {
        int chx =-1;

        //afficher menu
        afficherChaine(OutilsIhm.creerStrMenu(tabloStr), true);
        //faire choisir
        chx = saisirEntier(ConstantesIhm.MSG_INVITE,
                           ConstantesIhm.MENU1_CHX_MINI,
                       tabloStr.length -1);
        return chx;
    }

    @Override
    public int saisirEntier(String msg, int min, int max) {
        int saisie = 0;
        String strSaisie = null;
        boolean ok = false;
        do {
            //0) afficher message
            afficherChaine(msg + " ds [" + min + ":" + (max) + "[  ?", false);
            //1 faire saisir entier
            //saisie = scan.nextInt(); //1ere solution mais pbm InputMismatchException
            strSaisie = scan.nextLine();
            try {
                saisie = Integer.parseInt(strSaisie);

                //2 controler valeur ds [min:max[
                if (saisie >= min && saisie < max) {
                    ok=true;
                }else{
                    //2.a si pbm => afficher msg erreur + resaisir
                    afficherChaine("ERR: entier saisi hors intervalle demandé [" + min + ":" + max + "[", true);
                }
            } catch (NumberFormatException nfe) {
                afficherChaine("ERR: erreur de type de donnée saisi", true);
            }
        } while (!ok);
        //2.b renvoyer l'entier saisi
        return saisie;
    }
    
    @Override
    public void afficherChaine(String msg, boolean sautLigne) {
        if (sautLigne) {
            System.out.println(msg);
        } else {
            System.out.print(msg);
        }
    }

    @Override
    public void afficherChaine(String msg) {
        afficherChaine(msg,true);
    }

    private int[] rechercherMaxDsColonne(String[][] tab2){
        int[] tablow= new int[tab2.length];
        int idxColonne=0;
        int c=0;
        for(c =0;c<tab2[0].length;c++) {
            int l=0;
            int max =0;
            for(l =0;l<tab2.length;l++){
                if(tab2[l][c].length()>=max){
                    max= tab2[l][c].length();
                }
            }
            //Traitement tablo 1 colonne
            tablow[idxColonne]=max;
            idxColonne++;
        }

        return tablow;
    }
    public int getLargeurTotale(int[] tabloLg,boolean withNoLine){
        int total = 0;
        for(int i=0;i<tabloLg.length;i++){
            total+=tabloLg[i]+1;
        }
        if(withNoLine){
                total+=4;
        }
        return total;
    }

    public static final int NB_CAR=2;
    private String creerLigne(int lg,int lgEntete){
        StringBuilder strb = new StringBuilder();

        String str="";
        while(str.length()<(lg+(NB_CAR*lgEntete))){
            str+="-";
        }
        strb.append(str);
        return strb.toString();
    }


    private int[] rechercherMaxLargeur(String[] tabEntetes,String[][] tabDonnees){
        String [][] tabDonnes2 = new String[tabDonnees.length+1][tabDonnees[0].length];
        //recopie des donnes
        int l=0;
        for(l=0;l<tabDonnees.length;l++){
            for(int c=0;c<tabDonnees[l].length;c++){
                tabDonnes2[l][c]=tabDonnees[l][c];
            }
        }
        //ajout des entets

        for(int i=0;i<tabEntetes.length;i++){
            tabDonnes2[l][i]= tabEntetes[i];
        }

        //rechecrhe du max
        int[] tabloMax = rechercherMaxDsColonne(tabDonnes2);

        return tabloMax;

    }

    private String creerEntetes(String[] tabEntetes,TypeAlignement[] tabTa,int[] tabLargeursMax,int lgTot,boolean withNoLine){
        StringBuffer strb= new StringBuffer();
        strb.append(creerLigne(lgTot,(withNoLine?tabEntetes.length:0)));
        strb.append(System.lineSeparator());
        //entêtes
        if(withNoLine){
            strb.append("! no ");
        }

        for(int e=0;e<tabEntetes.length;e++){
            strb.append(OutilsIhm.alignerTexte(tabTa[e],tabEntetes[e],tabLargeursMax[e]));
        }
        strb.append("!");
        strb.append(System.lineSeparator());
        return strb.toString();
    }
    @Override
    public void afficherTableauEnHtml(String titre,String[] tabEntetes,String[][] tablo, TypeAlignement[] tabTa, boolean withNoLine) {
        //le titre
        StringBuilder strb = new StringBuilder();
        strb.append("\n"+(Objects.isNull(titre)?"Contenu":titre)).append(System.lineSeparator());

        //autres
        int[] tabLargeursMax = rechercherMaxLargeur(tabEntetes,tablo);
        int largeurTotale = getLargeurTotale(tabLargeursMax,withNoLine);

        strb.append(creerEntetes(tabEntetes,tabTa,tabLargeursMax,largeurTotale,withNoLine));

        //Données
        strb.append(creerLigne(largeurTotale,(withNoLine?tabEntetes.length:0)));
        strb.append(System.lineSeparator());

        for(int y=0;y<tablo.length;y++){
            if(withNoLine){
                strb.append(String.format("! %02d ",y));
            }
            for(int x=0;x<tablo[0].length;x++){
                strb.append(OutilsIhm.alignerTexte(tabTa[x],tablo[y][x],tabLargeursMax[x] ));

            }
            strb.append("!");
            strb.append(System.lineSeparator());
        }

        strb.append(creerLigne(largeurTotale,(withNoLine?tabEntetes.length:0)));
        strb.append(System.lineSeparator());

        afficherChaine(strb.toString(),true);
    }
}
